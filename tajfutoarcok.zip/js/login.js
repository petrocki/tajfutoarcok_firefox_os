$("#login-btn").on("click", function(){
	login();	
});